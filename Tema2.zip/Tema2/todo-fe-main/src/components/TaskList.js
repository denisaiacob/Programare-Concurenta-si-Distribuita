import React from 'react';
import { FaEdit, FaTrash } from 'react-icons/fa';

const TaskList = ({ tasks, toggleTask, deleteTask, startEditing }) => {
  return (
    <div className="task-container">
      <ul>
        {tasks.map((task) => (
          <li key={task.task}>
            <input 
              type="checkbox" 
              checked={task.completed} 
              onChange={() => toggleTask(task.task)} 
            />
            <div className="task-content">
              <span className={task.completed ? "completed" : ""}>
                {task.task}
              </span>
              {task.description && (
                <p className={`task-description ${task.completed ? "completed" : ""}`}>
                  {task.description}
                </p>
              )}
            </div>
            {task.duedate && (
              <div className="due-date">
                📅 Due: {new Date(task.duedate).toLocaleDateString()}
              </div>
            )}
            <div className="task-actions">
              <button onClick={() => startEditing(task)}>
                <FaEdit /> Edit
              </button>
              <button onClick={() => deleteTask(task.task)}> 
                <FaTrash /> Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;