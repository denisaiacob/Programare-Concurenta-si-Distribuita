package ro.example.todo_list.model.entities;

public enum RatedAt {
    I,
    II,
    III,
    IV,
    V,
    VI,
    VII,
    VIII,
    IX,
    X
}
