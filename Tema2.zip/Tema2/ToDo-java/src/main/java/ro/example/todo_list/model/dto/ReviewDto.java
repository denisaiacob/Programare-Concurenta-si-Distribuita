package ro.example.todo_list.model.dto;

import ro.example.todo_list.model.entities.Task;
import ro.example.todo_list.model.entities.RatedAt;
import ro.example.todo_list.model.entities.User;
import lombok.Data;

@Data
public class ReviewDto {

    private int id;

    private RatedAt rating;

    private String comment;

    private Task task;

    private User reviewer;
}
