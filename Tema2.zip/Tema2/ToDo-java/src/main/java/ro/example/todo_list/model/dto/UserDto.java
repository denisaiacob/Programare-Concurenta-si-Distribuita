package ro.example.todo_list.model.dto;

import ro.example.todo_list.model.entities.UserRole;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserDto {

    private int id;

    @NotEmpty(message = "User name should contain value")
    @NotBlank(message = "User name should contain value")
    @NotNull(message = "User name should contain value")
    @Size(min = 3, message = "User name length should be at least 3 characters")
    private String name;

    @NotEmpty(message = "Email should contain value")
    @NotBlank(message = "Email should contain value")
    @NotNull(message = "Email should contain value")
    private String email;

    @NotEmpty(message = "Password should contain value")
    @NotBlank(message = "Password should contain value")
    @NotNull(message = "Password should contain value")
    private String password;

    @NotEmpty(message = "Address should contain value")
    @NotBlank(message = "Address should contain value")
    @NotNull(message = "Address should contain value")
    private String address;

    @NotEmpty(message = "Phone should contain value")
    @NotBlank(message = "Phone should contain value")
    @NotNull(message = "Phone should contain value")
    private String phone;

    private UserRole userRole;

    private int wealth;
}
