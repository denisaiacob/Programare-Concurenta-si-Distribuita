package ro.example.todo_list.services.impl;

import ro.example.todo_list.exceptions.BadRequestException;
import ro.example.todo_list.exceptions.ResourceNotFoundException;
import ro.example.todo_list.model.entities.User;
import ro.example.todo_list.model.dto.UserDto;
import ro.example.todo_list.model.mappers.UserMapper;
import ro.example.todo_list.repositories.UserRepository;
import ro.example.todo_list.services.UserService;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final UserMapper userMapper;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.userMapper = new UserMapper();
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map((user) -> this.userMapper.toUserDtoWithoutPassword(user))
                .toList();
    }

    @Override
    public UserDto getUserById(int id) {
        if (id < 1) {
            throw new BadRequestException("Invalid user id");
        }
        User user= userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return this.userMapper.toUserDto(user);
    }

    @Override
    public UserDto getUserByEmail(String email) {
        if (email == null || email.isBlank()) {
            throw new BadRequestException("Invalid user email");
        }

        User userDb = userRepository.findUserByEmail(email).orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return userMapper.toUserDto(userDb);
    }

    @Override
    public UserDto createUser(UserDto body) {
        boolean emailExists = userRepository.existsUserByEmail(body.getEmail());

        if(emailExists) {
            throw new BadRequestException("User already exists");
        }
        String password = BCrypt.hashpw(body.getPassword(), BCrypt.gensalt());
        body.setPassword(password);

        User user = userMapper.toUser(body);

        return this.userMapper.toUserDto(userRepository.save(user));
    }

    @Override
    public UserDto updateUser(UserDto body) {
        UserDto userDb = this.getUserById(body.getId());

        if (!userDb.getEmail().equals(body.getEmail())) {

            boolean emailExists = userRepository.existsUserByEmail(body.getEmail());

            if (emailExists) {
                throw new BadRequestException("User email already exists");
            }
        }
        String password = BCrypt.hashpw(body.getPassword(), BCrypt.gensalt());
        body.setPassword(password);
        User user = userMapper.toUser(body);
        return this.userMapper.toUserDto(userRepository.save(user));
    }

    @Override
    public void deleteUserById(int id) {
        if(!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User not found");
        }

        userRepository.deleteById(id);
    }
}
