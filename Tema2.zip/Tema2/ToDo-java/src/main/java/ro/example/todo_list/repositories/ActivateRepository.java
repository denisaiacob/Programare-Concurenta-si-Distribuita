package ro.example.todo_list.repositories;

import ro.example.todo_list.model.entities.Activate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActivateRepository extends JpaRepository<Activate, Integer> {


}
