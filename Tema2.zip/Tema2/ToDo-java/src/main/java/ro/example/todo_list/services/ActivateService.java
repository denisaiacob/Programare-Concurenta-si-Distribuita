package ro.example.todo_list.services;

import ro.example.todo_list.model.dto.ActivateBodyDto;
import ro.example.todo_list.model.dto.ActivateDto;

import java.util.List;

public interface ActivateService {

    List<ActivateDto> getAllActivates();

    ActivateDto getActivateById(int id);

    ActivateDto createActivate(ActivateBodyDto body);

    ActivateDto updateActivate(ActivateBodyDto body);

    void deleteActivate(int id);
}
