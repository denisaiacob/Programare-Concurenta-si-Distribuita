package ro.example.todo_list.repositories;

import ro.example.todo_list.model.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findUserByName(String username);

    Optional<User> findUserByEmail(String email);

    boolean existsUserByEmail(String email);
}
