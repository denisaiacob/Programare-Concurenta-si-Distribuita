package ro.example.todo_list.services.impl;

import ro.example.todo_list.exceptions.BadRequestException;
import ro.example.todo_list.model.dto.UserDto;
import ro.example.todo_list.model.entities.UserRole;
import ro.example.todo_list.services.AuthService;
import ro.example.todo_list.services.UserService;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserService userService;

    public AuthServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDto login(Map<String, String> body) {
        if(body==null || body.isEmpty() || !body.containsKey("email") || !body.containsKey("password")) {
            throw new BadRequestException("Invalid credentials");
        }

        String email = body.get("email");
        String password = body.get("password");

        if(email.isBlank() || password.isBlank()) {
            throw new BadRequestException("Invalid email or password");
        }

        UserDto userDb = this.userService.getUserByEmail(email);

        boolean isMatch = BCrypt.checkpw(password, userDb.getPassword());
        if(!isMatch) {
            throw new BadRequestException("Invalid password");
        }

        return userDb;
    }

    @Override
    public UserDto register(UserDto body) {
        body.setUserRole(UserRole.CUSTOMER);
        return userService.createUser(body);
    }
}

