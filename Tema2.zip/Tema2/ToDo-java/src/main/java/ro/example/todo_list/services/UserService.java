package ro.example.todo_list.services;

import ro.example.todo_list.model.dto.UserDto;

import java.util.List;

public interface UserService {

    List<UserDto> getAllUsers();

    UserDto getUserById(int id);

    UserDto getUserByEmail(String email);

    UserDto createUser(UserDto body);

    UserDto updateUser(UserDto body);

    void deleteUserById(int id);

}
