package ro.example.todo_list.services.impl;

import ro.example.todo_list.exceptions.BadRequestException;
import ro.example.todo_list.exceptions.ResourceNotFoundException;
import ro.example.todo_list.model.dto.TaskDto;
import ro.example.todo_list.model.entities.Task;
import ro.example.todo_list.model.mappers.TaskMapper;
import ro.example.todo_list.repositories.TaskRepository;
import ro.example.todo_list.services.TaskService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final TaskMapper taskMapper;

    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
        this.taskMapper = new TaskMapper();
    }

    @Override
    public List<TaskDto> getAllTasks() {
        return taskRepository.findAll()
                .stream()
                .map((task) -> this.taskMapper.toTaskDto(task))
                .toList();
    }

    @Override
    public TaskDto getTaskById(int id) {

        if(id<1){
            throw new BadRequestException("Invalid task id");
        }

        Task taskDb = taskRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Task not found"));

        return taskMapper.toTaskDto(taskDb);
    }

    @Override
    public TaskDto createTask(TaskDto body) {

        Task taskDb = taskRepository.save(taskMapper.toTask(body));

        return taskMapper.toTaskDto(taskDb);
    }

    @Override
    public TaskDto updateTask(TaskDto body) {

        if(!taskRepository.existsById(body.getId())){
            throw new ResourceNotFoundException("Task not found");
        }

        Task taskDb = taskRepository.save(taskMapper.toTask(body));

        return taskMapper.toTaskDto(taskDb);
    }

    @Override
    public void deleteTask(int id) {

        if(!taskRepository.existsById(id)){
            throw new ResourceNotFoundException("Task not found");
        }

        taskRepository.deleteById(id);
    }
}
