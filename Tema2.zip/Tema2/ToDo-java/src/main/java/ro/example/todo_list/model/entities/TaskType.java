package ro.example.todo_list.model.entities;

public enum TaskType {

    EASY,
    MEDIUM,
    DIFFICULT,
    NONE
}
