package ro.example.todo_list.controllers;

import ro.example.todo_list.model.dto.TaskDto;
import ro.example.todo_list.services.TaskService;
import ro.example.todo_list.utils.ApiResponse;
import ro.example.todo_list.utils.UtilsResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllTasks() {
        return UtilsResponse.success("List with tasks", taskService.getAllTasks());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getTaskById(@PathVariable("id") int id) {
        return UtilsResponse.success("Task with id: " + id, taskService.getTaskById(id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse> createTask(@Valid @RequestBody TaskDto body) {
        return UtilsResponse.success("Create new task", taskService.createTask(body));
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateTask(@Valid @RequestBody TaskDto body) {
        return UtilsResponse.success("task updated", taskService.updateTask(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteTask(@PathVariable("id") int id) {
        taskService.deleteTask(id);

        return UtilsResponse.success("Task with id " + id + " deleted with success");
    }
}
