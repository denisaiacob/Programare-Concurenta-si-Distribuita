package ro.example.todo_list.services;

import ro.example.todo_list.model.dto.TaskDto;

import java.util.List;

public interface TaskService {

    List<TaskDto> getAllTasks();

    TaskDto getTaskById(int id);

    TaskDto createTask(TaskDto body);

    TaskDto updateTask(TaskDto body);

    void deleteTask(int id);

}
