package ro.example.todo_list.model.mappers;

import ro.example.todo_list.model.entities.Task;
import ro.example.todo_list.model.dto.TaskDto;
import org.springframework.stereotype.Component;

@Component
public class TaskMapper {

    public Task toTask(TaskDto taskDto) {
        Task task = new Task();

        task.setId(taskDto.getId());
        task.setName(taskDto.getName());
        task.setCategory(taskDto.getCategory());
        task.setDescription(taskDto.getDescription());
        task.setStars(taskDto.getStars());
        task.setIsReviewed(taskDto.getIsReviewed());
        task.setWorkerReview(taskDto.getWorkerReview());
        task.setCustomerReview(taskDto.getCustomerReview());
        task.setTaskLocation(taskDto.getTaskLocation());
        task.setTaskType(taskDto.getTaskType());


        return task;
    }

    public TaskDto toTaskDto(Task task) {
        TaskDto taskDto = new TaskDto();

        taskDto.setId(task.getId());
        taskDto.setName(task.getName());
        taskDto.setCategory(task.getCategory());
        taskDto.setStars(task.getStars());
        taskDto.setDescription(task.getDescription());
        taskDto.setIsReviewed(task.getIsReviewed());
        taskDto.setWorkerReview(task.getWorkerReview());
        taskDto.setCustomerReview(task.getCustomerReview());
        taskDto.setTaskLocation(task.getTaskLocation());
        taskDto.setTaskType(task.getTaskType());


        return taskDto;
    }
}
