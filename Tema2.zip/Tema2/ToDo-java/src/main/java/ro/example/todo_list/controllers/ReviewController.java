package ro.example.todo_list.controllers;

import ro.example.todo_list.model.dto.ReviewDto;
import ro.example.todo_list.services.ReviewService;
import ro.example.todo_list.utils.ApiResponse;
import ro.example.todo_list.utils.UtilsResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/reviews")
public class ReviewController {
    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllReviews() {
        return UtilsResponse.success("The reviews list as follows:", reviewService.getAllReviews());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getReviewById(@PathVariable("id") int id) {
        return UtilsResponse.success("Review with id: " + id, reviewService.getReviewById(id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse> createReview(@Valid @RequestBody ReviewDto body) {
        return UtilsResponse.success("Create new review", reviewService.createReview(body));
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateReview(@Valid @RequestBody ReviewDto body) {
        return UtilsResponse.success("Review updated", reviewService.updateReview(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteReview(@PathVariable("id") int id) {
        reviewService.deleteReview(id);

        return UtilsResponse.success("Review with id " + id + " deleted with success");
    }
}
