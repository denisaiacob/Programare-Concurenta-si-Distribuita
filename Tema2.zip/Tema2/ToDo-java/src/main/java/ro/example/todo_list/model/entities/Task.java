package ro.example.todo_list.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name="tasks")
@Data
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String category;

    @Column(columnDefinition = "text", nullable = false)
    private String description;

    @Column(nullable = false)
    private double stars;

    @Column
    private Boolean isReviewed;

    @Column
    private String WorkerReview;

    @Column
    private String CustomerReview;

    @Column(columnDefinition = "text", nullable = false)
    private String taskLocation;


    @Enumerated(value=EnumType.STRING)
    private TaskType taskType;

    @ManyToMany(mappedBy = "tasksList", fetch = FetchType.LAZY)
    @JsonIgnoreProperties("tasksList")
    private List<Activate> activateList;

    @OneToMany(mappedBy = "task")
    @JsonIgnoreProperties("task")
    private List<Review> reviewList;

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", name=" + name +
                ", category=" + category +
                ", description=" + description +
                ", stars=" + stars +
                ", isReviewed=" + isReviewed +
                ", WorkerReview=" + WorkerReview +
                ", CustomerReview=" + CustomerReview +
                ", taskLocation=" + taskLocation +
                ", taskType=" + taskType +
                '}';
    }
}
