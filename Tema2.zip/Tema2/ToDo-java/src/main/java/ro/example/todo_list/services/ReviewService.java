package ro.example.todo_list.services;

import ro.example.todo_list.model.dto.ReviewDto;

import java.util.List;

public interface ReviewService {

    List<ReviewDto> getAllReviews();

    ReviewDto getReviewById(int id);

    ReviewDto createReview(ReviewDto body);

    ReviewDto updateReview(ReviewDto body);

    void deleteReview(int id);

}
