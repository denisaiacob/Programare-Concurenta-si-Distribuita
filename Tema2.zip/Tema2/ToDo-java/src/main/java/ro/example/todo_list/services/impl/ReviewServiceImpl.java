package ro.example.todo_list.services.impl;

import ro.example.todo_list.exceptions.BadRequestException;
import ro.example.todo_list.exceptions.ResourceNotFoundException;
import ro.example.todo_list.model.dto.ReviewDto;
import ro.example.todo_list.model.entities.Review;
import ro.example.todo_list.model.mappers.ReviewMapper;
import ro.example.todo_list.repositories.ReviewRepository;
import ro.example.todo_list.services.ReviewService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final ReviewMapper reviewMapper;

    public ReviewServiceImpl(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
        this.reviewMapper = new ReviewMapper();
    }


    @Override
    public List<ReviewDto> getAllReviews() {
        return reviewRepository.findAll()
                .stream()
                .map((item) -> this.reviewMapper.toReviewDto(item))
                .toList();
    }

    @Override
    public ReviewDto getReviewById(int id) {
        if(id<1){
            throw new BadRequestException("Invalid review id");
        }

        Review reviewDb = reviewRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Review not found"));

        return reviewMapper.toReviewDto(reviewDb);
    }

    @Override
    public ReviewDto createReview(ReviewDto body) {
        Review reviewDb = reviewRepository.save(reviewMapper.toReview(body));

        return reviewMapper.toReviewDto(reviewDb);
    }

    @Override
    public ReviewDto updateReview(ReviewDto body) {
        if(!reviewRepository.existsById(body.getId())){
            throw new ResourceNotFoundException("Review not found");
        }

        Review reviewDb = reviewRepository.save(reviewMapper.toReview(body));

        return reviewMapper.toReviewDto(reviewDb);
    }

    @Override
    public void deleteReview(int id) {

        if(!reviewRepository.existsById(id)){
            throw new ResourceNotFoundException("Review not found");
        }

        reviewRepository.deleteById(id);
    }
}