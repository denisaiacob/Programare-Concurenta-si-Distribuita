package ro.example.todo_list.model.mappers;

import ro.example.todo_list.model.dto.ReviewDto;
import ro.example.todo_list.model.entities.Review;
import org.springframework.stereotype.Component;

@Component
public class ReviewMapper {

    public Review toReview(ReviewDto reviewDto) {
        Review review = new Review();

        review.setId(reviewDto.getId());
        review.setRating(reviewDto.getRating());
        review.setComment(reviewDto.getComment());

        return review;
    }

    public ReviewDto toReviewDto(Review review) {
        ReviewDto reviewDto = new ReviewDto();

        reviewDto.setId(review.getId());
        reviewDto.setRating(review.getRating());
        reviewDto.setComment(review.getComment());

        return reviewDto;
    }
}
