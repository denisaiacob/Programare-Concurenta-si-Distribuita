package ro.example.todo_list.controllers;

import ro.example.todo_list.model.dto.ActivateBodyDto;
import ro.example.todo_list.services.ActivateService;
import ro.example.todo_list.utils.ApiResponse;
import ro.example.todo_list.utils.UtilsResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/activates")
public class ActivateController {

    private final ActivateService activateService;

    public ActivateController(ActivateService activateService) {
        this.activateService = activateService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllActivates() {
        return UtilsResponse.success("Activate list", activateService.getAllActivates());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getActivateById(@PathVariable("id") int id) {
        return UtilsResponse.success("Activate with id: " + id , activateService.getActivateById(id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse> createActivate(@RequestBody ActivateBodyDto body) {
        return UtilsResponse.success("Activate successfully created", activateService.createActivate(body));
    }


    @PutMapping
    public ResponseEntity<ApiResponse> updateActivate(@RequestBody ActivateBodyDto body) {
        return UtilsResponse.success("Activate successfully updated", activateService.updateActivate(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteActivate(@PathVariable("id") int id) {
        activateService.deleteActivate(id);

        return UtilsResponse.success("Activate successfully deleted");
    }
}
