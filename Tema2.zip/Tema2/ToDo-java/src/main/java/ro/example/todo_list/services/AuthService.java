package ro.example.todo_list.services;

import ro.example.todo_list.model.dto.UserDto;

import java.util.Map;

public interface AuthService {

    UserDto login(Map<String, String> body);
    UserDto register(UserDto body);

}
