package ro.example.todo_list.model.dto;

import lombok.Data;
import ro.example.todo_list.model.entities.PaymentStatus;

import java.time.LocalDate;
import java.util.List;

@Data
public class ActivateDto {

    private int id;

    private LocalDate date;

    private double total;

    private String details;

    private PaymentStatus paymentStatus;

    private List<TaskDto> taskList;

    private UserDto customer;
}
