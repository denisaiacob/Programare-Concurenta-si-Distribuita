package ro.example.todo_list.model.dto;

import lombok.Data;

@Data
public class IdDto {
    private int id;
}
