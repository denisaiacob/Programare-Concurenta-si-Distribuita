package ro.example.todo_list.model.mappers;

import ro.example.todo_list.model.dto.ActivateDto;
import ro.example.todo_list.model.dto.TaskDto;
import ro.example.todo_list.model.dto.UserDto;
import ro.example.todo_list.model.entities.Activate;
import ro.example.todo_list.model.entities.Task;
import ro.example.todo_list.model.entities.User;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ActivateMapper {

    private final UserMapper userMapper;
    private final TaskMapper taskMapper;


    public ActivateMapper(UserMapper userMapper, TaskMapper taskMapper) {
        this.userMapper = userMapper;
        this.taskMapper = taskMapper;
    }

    public Activate toActivate(ActivateDto activateDto) {
        Activate activate = new Activate();
        activate.setId(activateDto.getId());
        activate.setTotal(activateDto.getTotal());
        activate.setDate(activateDto.getDate());
        activate.setDetails(activateDto.getDetails());
        activate.setPaymentStatus(activateDto.getPaymentStatus());

        User customer = userMapper.toUser(activateDto.getCustomer());
        activate.setCustomer(customer);
        List<Task> taskList = activateDto.getTaskList()
                .stream()
                .map((task) -> this.taskMapper.toTask(task))
                .toList();
        activate.setTasksList(taskList);

        return activate;
    }

    public ActivateDto toActivateDto(Activate activate) {
        ActivateDto activateDto = new ActivateDto();
        activateDto.setId(activate.getId());
        activateDto.setTotal(activate.getTotal());
        activateDto.setDate(activate.getDate());
        activateDto.setDetails(activate.getDetails());
        activateDto.setPaymentStatus(activate.getPaymentStatus());

        UserDto customer = userMapper.toUserDto(activate.getCustomer());
        activateDto.setCustomer(customer);

        List<TaskDto> taskDtoList = activate.getTasksList()
                .stream()
                .map((task) -> this.taskMapper.toTaskDto(task))
                .toList();

        activateDto.setTaskList(taskDtoList);

        return activateDto;
    }
}
