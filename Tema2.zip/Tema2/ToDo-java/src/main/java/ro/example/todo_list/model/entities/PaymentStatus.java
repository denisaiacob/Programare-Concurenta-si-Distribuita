package ro.example.todo_list.model.entities;

public enum PaymentStatus {

    RESERVED,
    PENDING,
    CANCELLED,
    CONFIRMED
}
