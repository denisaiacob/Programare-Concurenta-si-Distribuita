package ro.example.todo_list.controllers;

import ro.example.todo_list.model.dto.UserDto;
import ro.example.todo_list.services.AuthService;
import ro.example.todo_list.utils.ApiResponse;
import ro.example.todo_list.utils.UtilsResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody Map<String, String> body) {
        return UtilsResponse.success("Login successfull", authService.login(body));
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(@Valid @RequestBody UserDto body) {
        return UtilsResponse.success("Register successfull", authService.register(body));
    }
}
