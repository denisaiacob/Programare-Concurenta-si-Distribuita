package ro.example.todo_list.model.dto;

import jakarta.persistence.Column;
import ro.example.todo_list.model.entities.TaskType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class TaskDto {
    private int id;

    @NotNull(message = "Task should have a name")
    @NotBlank(message = "Task should have a name")
    @NotEmpty(message = "Task should have a name")
    private String name;

    @NotNull(message = "Task should have a category")
    @NotBlank(message = "Task should have a category")
    @NotEmpty(message = "Task should have a category")
    private String category;

    @NotNull(message = "Task should have a description")
    @NotBlank(message = "Task should have a description")
    @NotEmpty(message = "Task should have a description")
    private String description;

    private double stars;

    private Boolean isReviewed;

    @Column
    private String WorkerReview;

    @Column
    private String CustomerReview;

    private TaskType TaskType;

    private String taskLocation;
}
