package ro.example.todo_list.model.entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "activates")
@Data
public class Activate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;

    @Column(nullable = false)
    private double total;

    @Column(columnDefinition = "text", nullable = false)
    private String details;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @JsonIgnoreProperties("activatesList")
    private User customer;

    @ManyToMany
    @JoinTable(name = "activates_tasks", joinColumns = @JoinColumn(name = "activate_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "task_id", referencedColumnName = "id"))
    @JsonIgnoreProperties("activateList")
    List<Task> tasksList = new ArrayList<>();

    @Enumerated(value = EnumType.STRING)
    private PaymentStatus paymentStatus;

}
