package ro.example.todo_list.controllers;

import ro.example.todo_list.model.dto.UserDto;
import ro.example.todo_list.services.UserService;
import ro.example.todo_list.utils.ApiResponse;
import ro.example.todo_list.utils.UtilsResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/users")
@CrossOrigin("http://localhost:4200")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllUsers() {
        return UtilsResponse.success("Lista utilizatori", userService.getAllUsers());

    }

    @PostMapping
    public ResponseEntity<ApiResponse> createUser(@Valid @RequestBody UserDto body) {
        return UtilsResponse.success("Utilizator creat cu succes",
                userService.createUser(body));
    }

        @PutMapping
        public ResponseEntity<ApiResponse> updateUser (@Valid @RequestBody UserDto body){
            return UtilsResponse.success("Utilizator modificat cu succes",

                    userService.updateUser(body));
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<ApiResponse> deleteUser ( @PathVariable int id)
        {
            userService.deleteUserById(id);
            return UtilsResponse.success("Utilizator sters cu succes");

        }

        @GetMapping("/{id}")
        public ResponseEntity<ApiResponse> getUserById ( @PathVariable("id") int id){
            return UtilsResponse.success("Utilizatorul cu Id-ul " + id,
                    userService.getUserById(id));
        }
}
