package ro.example.todo_list.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Entity
@Table(name="users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false)
    private String phone;

    @Enumerated(value=EnumType.STRING)
    private UserRole role;

    @Column(nullable = false)
    private int wealth = 1000;

    @OneToMany(mappedBy = "customer")
    @JsonIgnoreProperties("customer")
    private List<Activate> activatesList;

    @OneToMany(mappedBy = "reviewer")
    private List<Review> reviewsList;

}
