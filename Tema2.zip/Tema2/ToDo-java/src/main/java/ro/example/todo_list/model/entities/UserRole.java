package ro.example.todo_list.model.entities;

public enum UserRole {
    ADMIN,
    CUSTOMER,
    WORKER
}
