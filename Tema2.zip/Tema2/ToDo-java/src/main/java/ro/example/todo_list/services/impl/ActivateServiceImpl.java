package ro.example.todo_list.services.impl;

import ro.example.todo_list.exceptions.BadRequestException;
import ro.example.todo_list.exceptions.ResourceNotFoundException;
import ro.example.todo_list.model.dto.ActivateBodyDto;
import ro.example.todo_list.model.dto.ActivateDto;
import ro.example.todo_list.model.dto.IdDto;
import ro.example.todo_list.model.entities.Activate;
import ro.example.todo_list.model.entities.Task;
import ro.example.todo_list.model.entities.User;
import ro.example.todo_list.model.mappers.ActivateMapper;
import ro.example.todo_list.repositories.ActivateRepository;
import ro.example.todo_list.repositories.TaskRepository;
import ro.example.todo_list.repositories.UserRepository;
import ro.example.todo_list.services.ActivateService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ActivateServiceImpl implements ActivateService {
    private final ActivateRepository activateRepository;
    private final ActivateMapper activateMapper;
    private final TaskRepository itemRepository;
    private final UserRepository userRepository;

    @Override
    public List<ActivateDto> getAllActivates() {
        List<ActivateDto> activateDtos = activateRepository.findAll()
                .stream()
                .map((activate) -> this.activateMapper.toActivateDto(activate))
                .toList();

        return activateDtos;
    }

    @Override
    public ActivateDto getActivateById(int id) {
        if (id < 1) {
            throw new BadRequestException("Invalid activate id");
        }
        Activate activateDb = activateRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No activate found"));

        return activateMapper.toActivateDto(activateDb);
    }

    @Override
    public ActivateDto createActivate(ActivateBodyDto body) {

        IdDto userId = body.getCustomer();
        User customer = userRepository.findById(userId.getId()).orElseThrow(() -> new ResourceNotFoundException("No user found"));

        List<Integer> itemIdList = body.getTaskList()
                .stream()
                .map((id) -> id.getId())
                .toList();
        List<Task> itemList = itemRepository.findAllById(itemIdList);

        Activate activate = new Activate();
        activate.setDate(body.getDate());
        activate.setTotal(body.getTotal());
        activate.setDetails(body.getDetails());
        activate.setPaymentStatus(body.getPaymentStatus());
        activate.setCustomer(customer);
        activate.setTasksList(itemList);

        return activateMapper.toActivateDto(activateRepository.save(activate));
    }

    @Override
    public ActivateDto updateActivate(ActivateBodyDto body) {
        if(!activateRepository.existsById(body.getId())) {
            throw new ResourceNotFoundException("Activate not found");
        }

        IdDto userId = body.getCustomer();
        User customer = userRepository.findById(userId.getId()).orElseThrow(() -> new ResourceNotFoundException("No user found"));

        List<Integer> itemIdList = body.getTaskList()
                .stream()
                .map((id) -> id.getId())
                .toList();
        List<Task> itemList = itemRepository.findAllById(itemIdList);

        Activate activate = new Activate();
        activate.setId(body.getId());
        activate.setDate(body.getDate());
        activate.setTotal(body.getTotal());
        activate.setDetails(body.getDetails());
        activate.setPaymentStatus(body.getPaymentStatus());
        activate.setCustomer(customer);
        activate.setTasksList(itemList);

        return activateMapper.toActivateDto(activateRepository.save(activate));
    }

    @Override
    public void deleteActivate(int id) {
        if (!activateRepository.existsById(id)) {
            throw new ResourceNotFoundException("No activate found");
        }
        activateRepository.deleteById(id);
    }

}
