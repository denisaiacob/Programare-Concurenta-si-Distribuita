import os
import random
import string

def generate_random_text_file(file_path: str, size_in_mb: int):
    """
    Generate a random text file with a specified size in MB.

    :param file_path: The path to save the generated file.
    :param size_in_mb: The desired size of the file in megabytes.
    """
    size_in_bytes = size_in_mb * 1024 * 1024
    chars = string.ascii_letters + string.digits + string.punctuation + ' \n'
    
    with open(file_path, 'w') as file:
        while os.path.getsize(file_path) < size_in_bytes:
            chunk_size = min(1024, size_in_bytes - os.path.getsize(file_path))
            file.write(''.join(random.choices(chars, k=chunk_size)))

    print(f"File '{file_path}' generated with size {os.path.getsize(file_path) / (1024 * 1024):.2f} MB.")


if __name__ == "__main__":
    file_name = input("Enter the file name (with .txt extension): ")
    size = int(input("Enter the desired file size in MB: "))
    
    generate_random_text_file(file_name, size)