import os
from pathlib import Path
import socket
import asyncio
from aioquic.quic.connection import QuicConnection
from aioquic.quic import events
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import HandshakeCompleted, StreamDataReceived, ConnectionTerminated
from aioquic.asyncio import QuicConnectionProtocol
from aioquic.asyncio import serve
import logging

logging.basicConfig(level=logging.INFO)

# class EchoQuicProtocol(QuicConnectionProtocol):
#     def __init__(self, quic: QuicConnection):
#         super().__init__(quic)  # Ensure we call the parent constructor
#         self.transport = None

#     def connection_made(self, transport):
#         self.transport = transport
#         logging.info("Connection established.")

#     def datagram_received(self, data, addr):
#         logging.info(f"Received data from {addr}: {data.decode(errors='ignore')}")
        
#         # Acknowledge the received data by sending it back to the sender
#         self.quic.send_datagram(data, addr)
#         logging.info(f"Sent acknowledgment to {addr}")

#     def error_received(self, exc):
#         logging.error(f"Error received: {exc}")

#     def connection_lost(self, exc):
#         logging.info("Connection lost.")

# async def server_QUIC():
#     # Create a QUIC configuration
#     config = QuicConfiguration(is_client=False)
#     config.load_cert_chain(certfile="cert.pem", keyfile="key.pem")

#     # Create a QUIC connection for the server
#     loop = asyncio.get_event_loop()
#     quic = QuicConnection(configuration=config, original_destination_connection_id=b'test')

#     # Initialize counters
#     mess_received = 0
#     bytes_received = 0

#     # Bind the server to a UDP endpoint
#     listen = loop.create_datagram_endpoint(
#         lambda: EchoQuicProtocol(quic),
#         local_addr=('0.0.0.0', 4443)
#     )

#     transport, protocol = await listen
#     logging.info("Server QUIC --- Waiting for client")

#     try:
#         # Keep the server running indefinitely
#         await asyncio.Future()  # This keeps the server alive until manually stopped
#     except asyncio.CancelledError:
#         transport.close()

#     # After the server is shut down, print statistics
#     print(f"The protocol used: QUIC")
#     print(f"The total number of messages received: {mess_received}")
#     print(f"The total number of bytes received: {bytes_received}")

# class EchoServerProtocol(QuicConnectionProtocol):
#     async def handle_stream(self, stream_id: int, data: bytes):
#         print(f"Server received: {data.decode()}")
#         # Echo the data back to the client
#         self._quic.send_stream_data(stream_id, data)
#         await self._loop.call_soon(self.transmit)

#     def quic_event_received(self, event):
#         if isinstance(event, HandshakeCompleted):
#             print("Handshake completed!")
#         elif isinstance(event, StreamDataReceived):
#             asyncio.ensure_future(self.handle_stream(event.stream_id, event.data))

# async def run_server():
#     configuration = QuicConfiguration(is_client=False)
#     configuration.load_cert_chain("cert.pem", "key.pem")
    
#     server = await serve("127.0.0.1", 5000, configuration=configuration, create_protocol=EchoServerProtocol)
#     print("Server TCP --- Wait for client")
    
#     # Keep server running
#     try:
#         await asyncio.Future()
#     except KeyboardInterrupt:
#         print("Server stopped")

class QUICServerProtocol(QuicConnectionProtocol):
    def __init__(self, *args, return_values, server_stop, **kwargs):
        super().__init__(*args, **kwargs)

        self.server_stop = server_stop
        self.return_values = return_values

        self.respond_back = False
        # if self.settings['method'] == "stop-and-wait":
        #     self.respond_back = True

        self.start_time = 0

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived):
            if "END" in event.data:
                print("Received end:", event.data)

                self.return_values["mess_received"] += 1
                self.return_values["bytes_received"] += len(event.data) - len("END")

                if self.respond_back:
                    self._quic.send_stream_data(0, b'ACK')
                    self.transmit()

                # Close the QUIC connection
                self._quic.close(error_code=0)
                # Ensures all buffered data is sent
                self.transmit()

                self.server_stop.set()
                self.close(error_code=0)
            else:
                self.return_values["mess_received"] += 1
                self.return_values["bytes_received"] += len(event.data)

                if self.respond_back:
                    self._quic.send_stream_data(0, b'ACK')
                    self.transmit()

        elif isinstance(event, ConnectionTerminated):
            print("Connection terminated")

            # Close the QUIC connection
            self._quic.close(error_code=0)
            # Ensures all buffered data is sent
            self.transmit()

            self.server_stop.set()
            self.close(error_code=0)

async def server_QUIC(mess_size):
    host = '127.0.0.1'
    port = 5000 

    configuration = QuicConfiguration(is_client=False)

    configuration.load_cert_chain(certfile=Path(os.path.join(os.getcwd(), "cert.pem")), keyfile=Path(os.path.join(os.getcwd(), "key.pem")))

    server_stop = asyncio.Event()

    return_values = {"mess_received": 0, "bytes_received": 0}
    server = await serve(host, port, configuration=configuration,
                         create_protocol=lambda *args, **kwargs: QUICServerProtocol(*args, return_values=return_values, server_stop=server_stop, **kwargs))

    print("Server initialized, ready to go")

    await server_stop.wait()
    print("Server stopped")

    # Properly close the QUIC server
    server.close()

    print("\n")
    print("The protocol used: QUIC")
    print("The total number of messages sent: " + str(return_values["mess_received"]))
    print("The total number of bytes sent: " + str(return_values["bytes_received"]))

def server_TCP(message_size):
    host = '127.0.0.1'
    port = 5000 

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    server_socket.bind((host, port))  

    print("Server TCP --- Wait for client")
    server_socket.listen(1)
    conn, address = server_socket.accept() 

    mess_received=0
    bytes_received=0
    while True:
        data = conn.recv(message_size)
        if not data:
            break
        mess_received += 1
        bytes_received += len(data)

    conn.close()  
    print("\n")
    print("The protocol used: TCP")
    print("The total number of messages received: " + str(mess_received))
    print("The total number of bytes received: " + str(bytes_received))


def server_UDP(message_size, stop_and_wait=False):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('127.0.0.1', 5000))
    print("Server UDP --- Wait for client")
    
    mess_received=0
    bytes_received=0

    while True:
        data, addr = server_socket.recvfrom(message_size)
        if not data:
            break
        if stop_and_wait:
           server_socket.sendto("ACK".encode(), addr)
        mess_received += 1
        bytes_received += len(data)

    server_socket.close()
    print("\n")
    print("The protocol used: UDP")
    print("The total number of messages received: " + str(mess_received))
    print("The total number of bytes received: " + str(bytes_received))

def server_UDP_streaming(message_size):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    server_socket.bind(('127.0.0.1', 5000))
    print("Server UDP --- Wait for client")
    
    mess_received=0
    bytes_received=0

    while True:
        data, addr = server_socket.recvfrom(message_size)
        if not data:
            break
        mess_received += 1
        bytes_received += len(data)
    
    server_socket.close()
    print("\n")
    print("The protocol used: UDP")
    print("The total number of messages received: " + str(mess_received))
    print("The total number of bytes received: " + str(bytes_received))

def server_UDP_stop_and_wait(message_size):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('127.0.0.1', 5000))
    print("Server UDP --- Wait for client")
    
    mess_received=0
    bytes_received=0

    while True:
        data, addr = server_socket.recvfrom(message_size)
        if not data:
            break
        server_socket.sendto(b"0", addr)
        mess_received += 1
        bytes_received += len(data)
    
    server_socket.close()
    print("\n")
    print("The protocol used: UDP")
    print("The total number of messages received: " + str(mess_received))
    print("The total number of bytes received: " + str(bytes_received))


if __name__ == "__main__":
    print("Which protocol do you want to use?\n 1. TCP\n 2. UDP\n 3. QUIC\n")
    protocol = int(input("The desired protocol number is: "))
    mess_size= int(input("The message size should be: "))
    if protocol == 1:
        server_TCP(mess_size)
    elif protocol == 2:
        transfer = input("The transfer mechanism should be Stop-and-Wait? (Y/N)")
        if transfer == "Y":
            # server_UDP(mess_size,True)
            server_UDP_stop_and_wait(mess_size)
        else:
            # server_UDP(mess_size,False)
            server_UDP_streaming(mess_size)
    elif protocol == 3:
        # asyncio.run(server_QUIC())
        asyncio.run(server_QUIC(mess_size))
    else:
        print("Incorrect protocol")