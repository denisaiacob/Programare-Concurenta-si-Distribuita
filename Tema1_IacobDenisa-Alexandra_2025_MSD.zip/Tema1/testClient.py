import subprocess
import time

client=0

def run_clientTest(protocol,input_size ,mess_size, transfer=None):
    global client
    mode = 'w' if client == 0 else 'a'
    client += 1

    client_input = f"{protocol}\n{input_size}\n{mess_size}\n"
    if transfer is not None:
        client_input += f"{transfer}\n"
    
    result= subprocess.run(
        ["python3", "client.py"], 
        input=client_input,
        text=True,
        capture_output=True
    )
    result_output = result.stdout.strip()
    result_output = result_output.splitlines()[-3:]
    print("CLIENT " +str(client) + " OUTPUT:\n","\n".join(result_output))

    with open("ClientOutputs.txt", mode) as file:
        file.write(f"CLIENT {client} OUTPUT:\n")
        file.write("\n".join(result_output))
        file.write("\n\n")


if __name__ == "__main__":
    # TCP
    run_clientTest(1,500,1024)
    time.sleep(1)
    run_clientTest(1,500,8000)
    time.sleep(1)
    run_clientTest(1,500,50000)
    time.sleep(1)
    run_clientTest(1,1000,1024)
    time.sleep(1)
    run_clientTest(1,1000,8000)
    time.sleep(1)
    run_clientTest(1,1000,50000)
    time.sleep(1)

    # UDP
    run_clientTest(2,500,1024,"Y")
    time.sleep(1)
    run_clientTest(2,500,1024,"N")
    time.sleep(1)
    run_clientTest(2,1000,1024,"Y")
    time.sleep(1)
    run_clientTest(2,1000,1024,"N")
    time.sleep(1)

    run_clientTest(2,500,8000,"Y")
    time.sleep(1)
    run_clientTest(2,500,8000,"N")
    time.sleep(1)
    run_clientTest(2,1000,8000,"Y")
    time.sleep(1)
    run_clientTest(2,1000,8000,"N")
    time.sleep(1)

    run_clientTest(2,500,50000,"Y")
    time.sleep(1)
    run_clientTest(2,500,50000,"N")
    time.sleep(1)
    run_clientTest(2,1000,50000,"Y")
    time.sleep(1)
    run_clientTest(2,1000,50000,"N")



