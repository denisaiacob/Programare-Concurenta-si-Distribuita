import subprocess
import time

server = 0

def run_serverTest(protocol, mess_size, transfer=None):
    global server 
    mode = 'w' if server == 0 else 'a'
    server += 1

    server_input = f"{protocol}\n{mess_size}\n"
    if transfer is not None:
        server_input += f"{transfer}\n"
    
    result = subprocess.run(
        ["python3", "server.py"], 
        input=server_input, 
        text=True,
        capture_output=True
    )
    result_output = result.stdout.strip()
    result_output = result_output.splitlines()[-3:]
    print("SERVER "+str(server) +" OUTPUT:\n","\n".join(result_output))

    with open("ServerOutputs.txt", mode) as file:
        file.write(f"SERVER {server} OUTPUT:\n")
        file.write("\n".join(result_output))
        file.write("\n\n")


if __name__ == "__main__":
    # TCP
    run_serverTest(1,1024)
    run_serverTest(1,8000)
    run_serverTest(1,50000)
    run_serverTest(1,1024)
    run_serverTest(1,8000)
    run_serverTest(1,50000)
    
    # UDP
    run_serverTest(2,1024,"Y")
    run_serverTest(2,1024,"N")
    run_serverTest(2,1024,"Y")
    run_serverTest(2,1024,"N")

    run_serverTest(2,8000,"Y")
    run_serverTest(2,8000,"N")
    run_serverTest(2,8000,"Y")
    run_serverTest(2,8000,"N")

    run_serverTest(2,50000,"Y")
    run_serverTest(2,50000,"N")
    run_serverTest(2,50000,"Y")
    run_serverTest(2,50000,"N")

