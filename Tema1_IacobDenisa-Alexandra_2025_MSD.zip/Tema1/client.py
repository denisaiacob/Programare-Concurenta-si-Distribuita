import socket
import time
import os
import asyncio
from aioquic.asyncio import connect
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.connection import QuicConnection
from aioquic.asyncio import QuicConnectionProtocol
from aioquic.quic.events import StreamDataReceived
import logging

logging.basicConfig(level=logging.INFO)

def read_input(filenanme, message_size):
    with open(filenanme, "rb") as input:
        while True:
            data = input.read(message_size)
            if not data:
                return
            yield data
        
def get_input_size(filenanme):
    return os.path.getsize(filenanme)

# async def client_QUIC(message_size, data_amounts):
#     # QUIC Configuration
#     config = QuicConfiguration(is_client=True)
#     config.load_cert_chain(certfile="cert.pem", keyfile="key.pem")

#     # Connect to the QUIC server
#     #loop = asyncio.get_event_loop()
#     transport, protocol = await connect(
#         '127.0.0.1', 4443,
#         configuration=config
#     )

#     # Prepare the QUIC connection
#     quic_connection = QuicConnection(configuration=config)

#     package_number = 0
#     bytes_sent = 0
#     start_time = time.time()

#     if data_amounts == 500:
#         input_file = "input500"
#     else:
#         input_file = "input1000"

#     # Stop-and-Wait mechanism
#     for data in read_input(input_file, message_size):
#         package_number += 1
#         bytes_sent += len(data)
#         logging.info(f"Sending message: {data.decode(errors='ignore')}")

#         # Send the datagram to the server (need to include destination address)
#         quic_connection.send_datagram(data, ('127.0.0.1', 4443))

#         # Wait for an acknowledgment from the server using async for
#         # Now, we will use `async for` to handle the generator returned by `protocol.receive()`
#         async for response in protocol.receive():
#             logging.info(f"Received acknowledgment: {response.decode(errors='ignore')}")
#             break  # Assuming we want to process only one acknowledgment for each message

#     transport.close()
#     end_time = time.time()
#     transmission_time = end_time - start_time

#     print("Total transmission time (in seconds): " + str(transmission_time))
#     print("The total number of messages sent: " + str(package_number))
#     print("The total number of bytes sent: " + str(bytes_sent))

# class EchoClientProtocol(QuicConnectionProtocol):
#     def quic_event_received(self, event):
#         if isinstance(event, StreamDataReceived):
#             print(f"Client received: {event.data.decode()}")
#             self._loop.stop()

# async def run_client():
#     configuration = QuicConfiguration(is_client=True)
#     configuration.verify_mode = False

#     async with connect("127.0.0.1", 5000) as connection:
#         stream_id = connection._quic.get_next_available_stream_id()
#         connection._quic.send_stream_data(stream_id, b"Hello, QUIC server!")
#         await connection.wait_closed()

class QUICClientProtocol(QuicConnectionProtocol):
    def __init__(self, *args, return_values, size_input, **kwargs):
        super().__init__(*args, **kwargs)

        self.return_values = return_values

        self.start_time = 0

        self.size_input = size_input

        self.await_response = False
        # if self.settings['method'] == "stop-and-wait":
        #     self.await_response = True
        #     self.received_ack = asyncio.Event()

    async def send_data(self):
        # Pre-allocating our buffer for future slicing
        buffer_data = b'0' * 65535

        stream_id = self._quic.get_next_available_stream_id()

        self.start_time = time.time()

        for block in self.size_input:
            # Sending only a slice of the buffer
            self._quic.send_stream_data(stream_id, buffer_data[:block])
            self.transmit()

            # Updating our metrics
            self.return_values["package_number"] += 1
            self.return_values["bytes_sent"] += block

            if self.await_response:
                # Wait for server response
                await self.received_ack.wait()
                # Reset for next message
                self.received_ack.clear()

        self._quic.send_stream_data(stream_id, "END")
        if self.await_response:
            # Wait for server response
            await self.received_ack.wait()
            # Reset for next message
            self.received_ack.clear()

        self.return_values["transmission_time"] = time.time() - self.start_time

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived) and event.data == b'ACK':
            self.received_ack.set()

async def client_QUIC(mess_size, size_input):
    host = '127.0.0.1'  
    port = 5000  
    configuration = QuicConfiguration(is_client=True)

    # Disable TLS verification for testing
    configuration.verify_mode = False

    return_values = {"package_number": 0, "bytes_sent": 0, "transmission_time": 0}
    async with connect(host,port, configuration=configuration,
                       create_protocol=lambda *args, **kwargs: QUICClientProtocol(*args, return_values=return_values, size_input=size_input, **kwargs)) as client:
        await client.send_data()

    print("\n")
    print("Total transmission time (in seconds): " + str(return_values["transmission_time"]))
    print("The total number of messages sent: " + str(return_values["package_number"]))
    print("The total number of bytes sent: " + str(return_values["bytes_sent"]))


def client_TCP(message_size,data_amounts):
    host = '127.0.0.1'  
    port = 5000  

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    client_socket.connect((host, port)) 

    package_number = 0
    bytes_sent = 0
    start_time = time.time()

    if data_amounts == 500:
        input_file = "input500"
    else:
        input_file = "input1000"
    
    for data in read_input(input_file, message_size):
        client_socket.send(data)
        package_number += 1
        bytes_sent += len(data)
    
    client_socket.close()
    end_time = time.time()
    transmission_time = end_time - start_time

    print("\n")
    print("Total transmission time (in seconds): " + str(transmission_time))
    print("The total number of messages sent: " + str(package_number))
    print("The total number of bytes sent: " + str(bytes_sent))


def client_UDP(message_size, data_amounts, stop_and_wait=False):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    package_number = 0
    bytes_sent = 0
    start_time = time.time()

    srv = ('127.0.0.1', 5000)

    if data_amounts == 500:
        input_file = "input500"
    else:
        input_file = "input1000"
    
    for data in read_input(input_file, message_size):
        client_socket.sendto(data, srv)

        package_number += 1
        bytes_sent += len(data)
        if stop_and_wait:
           try:
               client_socket.settimeout(0.1)
               ack, _ = client_socket.recvfrom(message_size)
           except socket.timeout:
               client_socket.sendto(data, srv)

    client_socket.sendto(b"", srv)
    
    client_socket.close()
    end_time = time.time()
    transmission_time = end_time - start_time

    print("\n")
    print("Total transmission time (in seconds): " + str(transmission_time))
    print("The total number of messages sent: " + str(package_number))
    print("The total number of bytes sent: " + str(bytes_sent))


def client_UDP_streaming(message_size, data_amounts):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    package_number = 0
    bytes_sent = 0
    start_time = time.time()

    srv = ('127.0.0.1', 5000)

    if data_amounts == 500:
        input_file = "input500"
    else:
        input_file = "input1000"
    
    for data in read_input(input_file, message_size):
        client_socket.sendto(data, srv)

        package_number += 1
        bytes_sent += len(data)

    client_socket.sendto(b"", srv)
    
    client_socket.close()
    end_time = time.time()
    transmission_time = end_time - start_time

    print("\n")
    print("Total transmission time (in seconds): " + str(transmission_time))
    print("The total number of messages sent: " + str(package_number))
    print("The total number of bytes sent: " + str(bytes_sent))


def client_UDP_stop_and_wait(message_size, data_amounts):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    package_number = 0
    bytes_sent = 0
    start_time = time.time()

    srv = ('127.0.0.1', 5000)

    if data_amounts == 500:
        input_file = "input500"
    else:
        input_file = "input1000"
    
    for data in read_input(input_file, message_size):
        client_socket.sendto(data, srv)

        package_number += 1
        bytes_sent += len(data)
        try:
               client_socket.settimeout(0.1)
               client_socket.recvfrom(message_size)
        except socket.timeout:
               client_socket.sendto(data, srv)
               package_number += 1
               bytes_sent += len(data)

    client_socket.sendto(b"", srv)
    
    client_socket.close()
    end_time = time.time()
    transmission_time = end_time - start_time

    print("\n")
    print("Total transmission time (in seconds): " + str(transmission_time))
    print("The total number of messages sent: " + str(package_number))
    print("The total number of bytes sent: " + str(bytes_sent))


if __name__ == "__main__":
    print("Which protocol do you want to use?\n 1. TCP\n 2. UDP\n 3. QUIC\n")
    protocol = int(input("The desired protocol number is: "))
    size_input=int(input("Data Transfer Amounts in MB: "))
    mess_size= int(input("The message size should be: "))
    if protocol == 1:
        client_TCP(mess_size, size_input)
    elif protocol == 2:
        transfer = input("The transfer mechanism should be Stop-and-Wait? (Y/N)")
        if transfer == "Y":
            # client_UDP(mess_size,size_input,True)
            client_UDP_stop_and_wait(mess_size,size_input)
        else:
            # client_UDP(mess_size,size_input,False)
            client_UDP_streaming(mess_size,size_input)
    elif protocol == 3:
        # asyncio.run(client_QUIC(1024,size_input))
        asyncio.run(client_QUIC(mess_size,size_input))
    else:
        print("Incorrect protocol")